import React from 'react'
import './footer.css'

export default function footer() {
  return (
  <footer className='footer'>
    Copyright @ 2024 Rohit kumar Saini. All Right Reserved.
  </footer>
  )
}
